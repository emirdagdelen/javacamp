package RecycleBinTest;
import Objects.*;
import IOs.*;
import RecycleBin.*;

public class GarbageRecyclingTest {

	public static void main(String[] args) {
		FileIO<Garbage> fileIO = new FileIO<>();
		TrashCan<Garbage> myTrashCan = (TrashCan<Garbage>)fileIO.readTrashCan();
		myTrashCan.start();

	}

}
