package IOs;

import java.io.*;
import Objects.Garbage;
import RecycleBin.*;
import RecycleBin.TrashCan;

public class FileIO<T> {

	public IBag<Garbage> readTrashCan(){
		IBag<Garbage> myTrashCan = new TrashCan<>();
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader("garbage.txt"));
			String line = reader.readLine();
			while (line != null) {
				String[] line1=line.split(",",3);				
				int garbageAmount =Integer.parseInt(line1[2].replace(" ", ""));
				for (int i = 0; i < garbageAmount; i++) {
					Garbage aGarbage = new Garbage(line1[0], line1[1]);
					myTrashCan.add(aGarbage);
				}
				line = reader.readLine();
			}
			reader.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return myTrashCan;
	}
	
	public boolean updateTrashCan(TrashCan<T> trashBag) {
		try {
			new FileWriter("updatedGarbage", false).close();
			BufferedWriter writer = new BufferedWriter(new FileWriter("updatedGarbage"));
			for (int i = 0; i < trashBag.getItemCount(); i++) {
				writer.write(trashBag.trashBin[i].toString()+"\n");
			}
			writer.close();
		}
		catch (Exception e) {
		      e.getStackTrace();
		    }
		return true;
	}

}
