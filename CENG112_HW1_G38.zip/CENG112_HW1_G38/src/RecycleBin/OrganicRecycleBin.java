package RecycleBin;

public class OrganicRecycleBin<T> extends Bag<T>  {

}
