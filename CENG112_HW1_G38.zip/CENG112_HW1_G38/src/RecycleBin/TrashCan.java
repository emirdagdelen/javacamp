package RecycleBin;
import Objects.Garbage;
import IOs.FileIO;
public class TrashCan<T> implements IBag<T> {
	
	public T[] trashBin;
	private static int sizeOfTrashCan = 450;
	private int currentEntry = 0;
	FabricRecycleBin<T> myFabricRecycleBin = new FabricRecycleBin<>();
	GlassRecycleBin<T> myGlassRecycleBin = new GlassRecycleBin<>();
	MetalRecycleBin<T> myMetalRecycleBin = new MetalRecycleBin<>();
	OrganicRecycleBin<T> myOrganicRecycleBin = new OrganicRecycleBin<>();
	PaperRecycleBin<T> myPaperRecycleBin = new PaperRecycleBin<>();
	PlasticRecycleBin<T> myPlasticRecycleBin = new PlasticRecycleBin<>();
	FileIO<T> fileio = new  FileIO<>();
			
	public FabricRecycleBin<T> getMyFabricRecycleBin() {
		return myFabricRecycleBin;
	}

	public GlassRecycleBin<T> getMyGlassRecycleBin() {
		return myGlassRecycleBin;
	}

	public MetalRecycleBin<T> getMyMetalRecycleBin() {
		return myMetalRecycleBin;
	}

	public OrganicRecycleBin<T> getMyOrganicRecycleBin() {
		return myOrganicRecycleBin;
	}

	public PaperRecycleBin<T> getMyPaperRecycleBin() {
		return myPaperRecycleBin;
	}

	public PlasticRecycleBin<T> getMyPlasticRecycleBin() {
		return myPlasticRecycleBin;
	}

	public void setMyFabricRecycleBin(FabricRecycleBin<T> myFabricRecycleBin) {
		this.myFabricRecycleBin = myFabricRecycleBin;
	}

	public void setMyGlassRecycleBin(GlassRecycleBin<T> myGlassRecycleBin) {
		this.myGlassRecycleBin = myGlassRecycleBin;
	}

	public void setMyMetalRecycleBin(MetalRecycleBin<T> myMetalRecycleBin) {
		this.myMetalRecycleBin = myMetalRecycleBin;
	}

	public void setMyOrganicRecycleBin(OrganicRecycleBin<T> myOrganicRecycleBin) {
		this.myOrganicRecycleBin = myOrganicRecycleBin;
	}

	public void setMyPaperRecycleBin(PaperRecycleBin<T> myPaperRecycleBin) {
		this.myPaperRecycleBin = myPaperRecycleBin;
	}

	public void setMyPlasticRecycleBin(PlasticRecycleBin<T> myPlasticRecycleBin) {
		this.myPlasticRecycleBin = myPlasticRecycleBin;
	}

	@SuppressWarnings("unchecked")
	public TrashCan(){
		trashBin = (T[]) new Object[sizeOfTrashCan];
		
	}
		
	public boolean add(T newItem) {
		if(!isFull()) {
			trashBin[currentEntry] = newItem;
			currentEntry++;
			return true;
		}
		else {
			return false;
		}	
	}
	
	public boolean isEmpty() {
		return currentEntry==0;
	}

	public boolean isFull() {		
		return currentEntry==sizeOfTrashCan;
	}

	public T removeByIndex(int index) {
		if(!(index>currentEntry-1)) {
			T removedGarbage = trashBin[index];
			trashBin[index]=trashBin[currentEntry-1];
			trashBin[currentEntry-1]=null;
			currentEntry--;
			return removedGarbage;
		}
		else {
			return null;
		}
	}

	public T remove() {	
		return null;
	}

	
	public T remove(T item) {
		int indexOfItem = getIndexOf(item);
		if(indexOfItem != -1) {
			trashBin[indexOfItem]=trashBin[currentEntry-1];
			trashBin[currentEntry-1]=null;
			currentEntry--;
			return item;
		}	
		return null;
	}
	
	public int getItemCount() {
		return currentEntry;
	}
	
	public int getIndexOf(T item) {
		int index=-1;
		for (int i = 0; i < currentEntry; i++) {
			if(trashBin[i]==item) {
				index=i;
				return index;	
			}
		}	
		return index;
	}

	public boolean contains(T item) {		
		return getIndexOf(item)==-1;
	}
	
	public void displayItems() {
		for (int i = 0; i < currentEntry; i++) {
			System.out.print(trashBin[i]);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void dump() {
		trashBin = null;
		trashBin =(T[]) new Object[sizeOfTrashCan];
		
	}
	
	public boolean transferTo(IBag<T> targetBag, T item) {
		targetBag.add(item);
		remove(item);
		return true;
	}
	
	public boolean seperate(T item) {
		Garbage temporalItem =(Garbage) item;
		switch (temporalItem.getType()) {
		case "fabric":
			if(!myFabricRecycleBin.isFull()) {
				transferTo(myFabricRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;
			}
			return false;		
		case "glass":
			if(!myGlassRecycleBin.isFull()) {
				transferTo(myGlassRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;	
			}
			return false;
				
		case "metal":
			if(!myMetalRecycleBin.isFull()) {
				transferTo(myMetalRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;	
			}
			return false;
				
		case "organic":
			if(!myOrganicRecycleBin.isFull()) {
				transferTo(myOrganicRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;
			}
			return false;
						
		case "paper":
			if(!myPaperRecycleBin.isFull()) {
				transferTo(myPaperRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;	
			}
			return false;
	
		case "plastic":
			if(!myPlasticRecycleBin.isFull()) {
				transferTo(myPlasticRecycleBin, item);
				fileio.updateTrashCan(this);
				return true;
			}		
			return false;
		}
		return false;
	}
	public void start() {
		for (int i = 0; i < getItemCount(); i++) {
			if(myPlasticRecycleBin.isEmpty()&&myFabricRecycleBin.isEmpty()&&myGlassRecycleBin.isEmpty()&&myMetalRecycleBin.isEmpty()&&myOrganicRecycleBin.isEmpty()&&myPaperRecycleBin.isEmpty()) {
				System.out.println("The content of TrashCan : ");
				System.out.println();
				checkEqualityOfObjectsInTrash();
				System.out.println("************");
			}
			seperate(trashBin[i]);
			if(myPlasticRecycleBin.isFull()&&myFabricRecycleBin.isFull()&&myGlassRecycleBin.isFull()&&myMetalRecycleBin.isFull()&&myOrganicRecycleBin.isFull()&&myPaperRecycleBin.isFull()) {
				
				System.out.println("PlasticRecycleBin : ");
				System.out.println("The size of PlasticRecycleBin is:" + myPlasticRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myPlasticRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("PaperRecycleBin : ");
				System.out.println("The size of PaperRecycleBin is:" + myPaperRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myPaperRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("MetalRecycleBin : ");
				System.out.println("The size of MetalRecycleBin is:" + myMetalRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myMetalRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("FabricRecycleBin : ");
				System.out.println("The size of FabricRecycleBin is:" + myFabricRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myFabricRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("OrganicRecycleBin : ");
				System.out.println("The size of OrganicRecycleBin is:" + myOrganicRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myOrganicRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("GlassRecycleBin : ");
				System.out.println("The size of GlassRecycleBin is:" + myGlassRecycleBin.getRandomSizeOfBins());
				System.out.println();
				myGlassRecycleBin.displayItems();
				System.out.println();
				System.out.println("************");
				System.out.println();
				System.out.println("The updated content of TrashCan : ");
				System.out.println();
				checkEqualityOfObjectsInTrash();
				System.out.println("************");
				break;
			}									
		}
	}
	public void checkEqualityOfObjectsInTrash() {
		int iHaveItemNumber=0;
		int sameContent=1;
		for (int i = 0; i < currentEntry; i++) {
			for (int j = i+1; j < currentEntry; j++) {
				if(trashBin[i].equals(trashBin[j])&&((Garbage) trashBin[j]).equalityChecker==false) {
					((Garbage) trashBin[j]).equalityChecker=true;
					sameContent++;
				}
			}
			if(((Garbage) trashBin[i]).equalityChecker==false){
				System.out.println(trashBin[i]+" "+ String.valueOf(sameContent));
				iHaveItemNumber+=sameContent;
				sameContent=1;
			}
			((Garbage) trashBin[i]).equalityChecker=false;
			
		}
		System.out.println("the number of item is in TrashCan: "+iHaveItemNumber);
	}
	
	
	
}
