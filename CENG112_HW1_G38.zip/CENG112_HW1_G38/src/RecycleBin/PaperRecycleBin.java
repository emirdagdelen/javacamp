package RecycleBin;

public class PaperRecycleBin<T> extends Bag<T> {

}
