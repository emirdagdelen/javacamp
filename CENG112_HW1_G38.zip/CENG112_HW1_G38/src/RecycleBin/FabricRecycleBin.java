package RecycleBin;

public class FabricRecycleBin <T> extends Bag<T> {

}
