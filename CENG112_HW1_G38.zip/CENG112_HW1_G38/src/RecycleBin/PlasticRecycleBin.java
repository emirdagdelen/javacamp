package RecycleBin;

public class PlasticRecycleBin<T> extends Bag<T> {

}
