package RecycleBin;

public class MetalRecycleBin<T> extends Bag<T> {

}
