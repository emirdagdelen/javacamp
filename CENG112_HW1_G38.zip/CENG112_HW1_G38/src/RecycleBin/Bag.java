package RecycleBin;

import java.util.*;

public class Bag<T> implements IBag<T> {
	
	private T[] bin;
	private final int[] sizeArray = {5, 10, 15};
	private int randomSizeOfBins;
	private int currentEntry = 0;
	
	public T[] getBin() {
		return bin;
	}

	public int[] getSizeArray() {
		return sizeArray;
	}

	public int getRandomSizeOfBins() {
		return randomSizeOfBins;
	}

	public int getCurrentEntry() {
		return currentEntry;
	}

	public void setBin(T[] bin) {
		this.bin = bin;
	}

	public void setRandomSizeOfBins(int randomSizeOfBins) {
		this.randomSizeOfBins = randomSizeOfBins;
	}

	public void setCurrentEntry(int currentEntry) {
		this.currentEntry = currentEntry;
	}

	{
		this.randomSizeOfBins = sizeArray[new Random().nextInt(sizeArray.length)];
	}
	
	@SuppressWarnings("unchecked")
	public Bag(){
		bin = (T[]) new Object[randomSizeOfBins];
		
	}
		
	public boolean add(T newItem) {
		if(!isFull()) {
			bin[currentEntry] = newItem;
			currentEntry++;
			return true;
		}
		else {
			return false;
		}	
	}
	
	public boolean isEmpty() {
		return currentEntry==0;
	}

	public boolean isFull() {		
		return currentEntry==randomSizeOfBins;
	}

	public T removeByIndex(int index) {
		if(!(index>currentEntry-1)) {
			T removedGarbage = bin[index];
			bin[index]=bin[currentEntry-1];
			bin[currentEntry-1]=null;
			currentEntry--;
			return removedGarbage;
		}
		else {
			return null;
		}
	}

	public T remove() {	
		return null;
	}

	
	public T remove(T item) {
		int indexOfItem = getIndexOf(item);
		if(indexOfItem != -1) {
			bin[indexOfItem]=bin[currentEntry-1];
			bin[currentEntry-1]=null;
			currentEntry--;
			return item;
		}	
		return null;
	}
	
	public int getItemCount() {
		return currentEntry;
	}
	
	public int getIndexOf(T item) {
		int index=-1;
		for (int i = 0; i < currentEntry; i++) {
			if(bin[i]==item) {
				index=i;
				return index;	
			}
		}	
		return index;
	}

	public boolean contains(T item) {		
		return getIndexOf(item)==-1;
	}
	
	public void displayItems() {
		for (int i = 0; i < currentEntry; i++) {
			System.out.println(bin[i]);
		}
		//System.out.println();
	}

	
	@SuppressWarnings("unchecked")
	public void dump() {
		bin = null;
		bin =(T[]) new Object[randomSizeOfBins];
				
	}

	
	public boolean transferTo(IBag<T> targetBag, T item) {
		targetBag.add(item);
		remove(item);
		return true;
	}
	
	
	

}
