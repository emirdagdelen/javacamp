package RecycleBin;

public class GlassRecycleBin<T> extends Bag<T> {

}
